#pragma once
#include "JSON.h"
#include "Game.h"

class EntityManager
{
public:
	static void InitManager(entt::registry* temp);
	static void CreateTab();
	static void CreateManager();

private:
	static int CurrentAnim;
	static bool Animation0;
	static bool Animation1;
	static bool Swaping;

	static bool randomized;
	static bool randomized2;
	static bool rotating;
	static bool rotating2;
	static Selectable m_selectable;
	static entt::registry* m_register;
};