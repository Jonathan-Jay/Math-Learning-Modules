//
//  GameViewController.h
//  imguiex

// This is the OpenGL Example template from XCode, modified to support ImGui

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface GameViewController : GLKViewController

@end
