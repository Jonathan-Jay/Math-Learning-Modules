# SpriteLib3.0
The 2D-Graphics Framework made for the Essential Math for Games I class at Ontario Tech University.
